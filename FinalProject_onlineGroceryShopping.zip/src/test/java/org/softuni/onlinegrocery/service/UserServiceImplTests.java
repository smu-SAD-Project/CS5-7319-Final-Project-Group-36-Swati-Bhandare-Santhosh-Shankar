package org.softuni.onlinegrocery.service;

import org.junit.Test;

import static org.junit.Assert.*;

public class UserServiceImplTests {

    @Test
    public void loadUserByUsername() {
    }

    @Test
    public void register() {
    }

    @Test
    public void findAllUsers() {
    }

    @Test
    public void findByUsername() {
    }

    @Test
    public void findById() {
    }

    @Test
    public void updateRole() {
    }

    @Test
    public void findUserByUserName() {
    }
}
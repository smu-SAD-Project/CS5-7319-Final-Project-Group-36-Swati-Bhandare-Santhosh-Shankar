package org.softuni.onlinegrocery.service;

import org.junit.Test;

import static org.junit.Assert.*;

public class OfferServiceImplTests {

    @Test
    public void findAllOffers() {
    }
}